#!/bin/bash
# DreamForge 造梦工坊 · macOS 启动脚本
# 双击本文件即可启动（首次可能需要右键 → 打开）

cd "$(dirname "$0")" || exit 1

PORT=3000

echo ""
echo "  ============================================"
echo "    DreamForge 造梦工坊"
echo "  ============================================"
echo ""

# 优先使用包内自带的 Node（Apple Silicon 版）
if [ -x "./node/bin/node" ]; then
  NODE="./node/bin/node"
elif command -v node >/dev/null 2>&1; then
  NODE="node"
  echo "  提示：未使用内置运行时，改用系统安装的 Node"
else
  echo "  [!] 没有可用的 Node 运行时。"
  echo ""
  echo "      这个包内置的是 Apple Silicon（M1/M2/M3…）版 Node。"
  echo "      如果你的 Mac 是 Intel 芯片，请改用源码方式运行："
  echo "        1. 安装 Node 18+（https://nodejs.org）"
  echo "        2. 在本文件夹执行：node server.js"
  echo ""
  echo "      或者联系分享者要 Intel 版。"
  echo ""
  read -n 1 -s -r -p "  按任意键关闭..."
  exit 1
fi

# 端口占用检查
if command -v lsof >/dev/null 2>&1; then
  if lsof -nP -iTCP:$PORT -sTCP:LISTEN >/dev/null 2>&1; then
    echo "  [!] 端口 $PORT 已被占用。"
    echo "      可能是 DreamForge 已经在运行（浏览器打开 http://localhost:$PORT 试试），"
    echo "      也可能是别的程序。想换端口：用文本编辑打开本文件，把 PORT=3000 改成别的。"
    echo ""
    read -n 1 -s -r -p "  按任意键关闭..."
    exit 1
  fi
fi

echo "  正在启动（端口 $PORT）..."
echo ""

PORT=$PORT "$NODE" server.js &
SERVER_PID=$!

# 等服务就绪后再打开浏览器（最多等 9 秒）
for _ in $(seq 1 30); do
  if curl -s -o /dev/null "http://127.0.0.1:$PORT/" 2>/dev/null; then
    open "http://localhost:$PORT"
    break
  fi
  sleep 0.3
done

echo ""
echo "  ------------------------------------------------------------"
echo "  浏览器已打开。关掉这个窗口或按 Control + C 即可停止服务。"
echo "  ------------------------------------------------------------"
echo ""

wait $SERVER_PID
